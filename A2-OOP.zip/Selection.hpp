#pragma once

#include "Waterfall.hpp"

class Selection
{
public:
    // The maximum number of Waterfall objects that can be stored
    static const size_t MAX_COUNT{ 5 };

    // Initialization
    void init() { _count = 0; }

    // Return the current number of stored Waterfall objects
    size_t get_count() { return _count; }

    // Return a Waterfall object by index or a default object if the index is invalid
    Waterfall get(size_t i) { return (i < _count) ? _items[i] : Waterfall{}; }

    // Add a new Waterfall object to the selection
    void add(std::string location, double height, float flow_rate, std::string type);

    // Search for a Waterfall that closely matches the query, or return a default object
    Waterfall search(Waterfall query);

private:
    // Container for storing selected Waterfall objects
    Waterfall _items[Selection::MAX_COUNT];

    // Number of currently stored Waterfall objects
    size_t _count;
};
