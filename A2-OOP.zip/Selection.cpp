#include "Selection.hpp"
#include <cmath> // for std::abs()

void Selection::add(std::string location, double height, float flow_rate, std::string type)
{
    if (_count < Selection::MAX_COUNT)
    {
        Waterfall new_item;
        new_item.init(location, height, flow_rate, type);
        _items[_count] = new_item;
        _count++;
    }
}

Waterfall Selection::search(Waterfall query)
{
    for (size_t i{ 0 }; i < _count; i++)
    {
        // For string type property
        if (!query.get_location().empty()
            && query.get_location() != _items[i].get_location())
            continue;

        // For double type property (height)
        constexpr double height_epsilon{ 0.005 };
        if (query.get_height() > 0.0
            && height_epsilon < std::abs(query.get_height() - _items[i].get_height()))
            continue;

        // For float type property (flow rate)
        constexpr float flow_epsilon{ 0.005f };
        if (query.get_flow_rate() > 0.0f
            && flow_epsilon < std::abs(query.get_flow_rate() - _items[i].get_flow_rate()))
            continue;

        // For string type property (waterfall type)
        if (!query.get_type().empty()
            && query.get_type() != _items[i].get_type())
            continue;

        return _items[i];
    }

    return Waterfall{}; // Return a default Waterfall object if nothing matches
}
