//
// Created by Hp on 26/02/2025.
//
#pragma once
#ifndef WATERFALL_H
#define WATERFALL_H
#include <string>
#include <chrono>


class Waterfall {
public:
    void init(std::string location, double height, float flow_rate, std::string type);
    // Getters
    std::string get_location() { return _location; }
    double get_height() { return _height; }
    float get_flow_rate() { return _flow_rate; }
    std::string get_type() { return _type; }

private:
    std::string _location;  // Geographical location of the waterfall
    double _height;         // Height in meters
    float _flow_rate;       // Flow rate in cubic meters per second
    std::string _type;      // Type of waterfall

};



#endif //WATERFALL_H
