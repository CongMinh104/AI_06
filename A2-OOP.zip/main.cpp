#include "Waterfall.hpp"
#include "Selection.hpp"
#include <iostream>
#include <iomanip>
#include <cassert>  // Include for assert()

// Function to display Waterfall object properties
void show(Waterfall item)
{
    std::cout << "'" << item.get_location() << "' "
              << std::fixed << std::setprecision(2) << item.get_height() << "m "
              << item.get_flow_rate() << " m³/s "
              << "'" << item.get_type() << "'"
              << std::endl;
}

int main()
{
    Selection sel;
    sel.init();

    // Ensure selection is empty at initialization
    assert(sel.get_count() == 0);

    // Add several different Waterfall objects to the selection
    sel.add("Niagara Falls", 51.0, 2800.0, "Plunge");
    sel.add("Angel Falls", 979.0, 500.0, "Plunge");
    sel.add("Iguazu Falls", 82.0, 1756.0, "Tiered");
    sel.add("Victoria Falls", 108.0, 1088.0, "Cascade");

    // Ensure the selection count increased correctly
    assert(sel.get_count() == 4);

    Waterfall qry;
    Waterfall result;

    // Search for waterfall with a specific location
    qry.init("Angel Falls", 0.0, 0.0, "");
    result = sel.search(qry);
    show(result);
    assert(result.get_location() == "Angel Falls");

    // Search for waterfall by type
    qry.init("", 0.0, 0.0, "Plunge");
    result = sel.search(qry);
    show(result);
    assert(result.get_type() == "Plunge");

    // Search for waterfall with a specific height
    qry.init("", 108.0, 0.0, "");
    result = sel.search(qry);
    show(result);
    assert(result.get_height() == 108.0);

    // Search for non-matching waterfall (should return default)
    qry.init("Imaginary Falls", 0.0, 0.0, "");
    result = sel.search(qry);
    show(result);
    assert(result.get_location().empty());  // Default object should have an empty location

    return 0;
}


// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.