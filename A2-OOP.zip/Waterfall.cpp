//
// Created by Hp on 26/02/2025.
//

#include "Waterfall.hpp"

void Waterfall::init(std::string location, double height, float flow_rate, std::string type)
{
    _location = location;
    _height = height;
    _flow_rate = flow_rate;
    _type = type;
}